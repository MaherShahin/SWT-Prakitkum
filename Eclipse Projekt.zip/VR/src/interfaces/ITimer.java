package interfaces;

/**
 * Interface for automatically called methods by a Timer.
 * 
 * @author swe.uni-due.de
 *
 */
public interface ITimer {

	public void checkPayment();

}
