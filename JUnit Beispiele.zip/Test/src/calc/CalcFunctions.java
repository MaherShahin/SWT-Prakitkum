package calc;

public class CalcFunctions {

	public static int multiply(int x, int y) {
		return x*y;
	}
}
