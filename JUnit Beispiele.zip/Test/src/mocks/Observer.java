package mocks;

public class Observer {

	public Observer() {
		super();
	}

	public void update(String s) {
		System.out.println(s);
	}
}
